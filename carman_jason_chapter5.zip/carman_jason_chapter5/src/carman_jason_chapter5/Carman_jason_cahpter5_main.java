package carman_jason_chapter5;
/*
 * Professor Carman
 * Summer 2015
 * Chapter 5
 * Long winded and overly thorough description of what this program does
 */
public class Carman_jason_cahpter5_main {
	//Creates the main module, every program must have one
	//Program starts here
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Declares variable local to main
		String mainVariable = "Hello There";
		//Outputs variable local to main
		System.out.println(mainVariable);
		//Calls method which we created below
		mySecondMethod();
		//Calls method which we created below
		myFirstmethod();
		//Outputs variable local to main
		System.out.println(mainVariable);
		
	}

	//Method 1, this creates a variable then outputs
	//that variable to the screen
	public static void myFirstmethod()  {
		//Declares variable local to this method
		String methodVariable = "Hi There";
		//Outputs variable local to this method
		System.out.println(methodVariable);
		//Calls the method created below
		mySecondMethod();
	}
	//Method 2, this creates a variable then outputs
	//that variable to the screen
	public static void mySecondMethod()  {
		//Declares variable local to this method
		String method2Variable = "Howdy";
		//Outputs variable local to this method
		System.out.println(method2Variable);
	}
	
}
