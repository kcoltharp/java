package carman_jason_58;

import java.util.Scanner;

/*
 * Professor Carman
 * Summer 2015
 * Question 5-8
 * This program allows the user to enter which of three conversions
 * they would like to make.  The program will keep running until the
 * user chooses the option to make the program stop
 * Once an option for conversion has been chosen, the program
 * will select the approprate method to run
 */
public class Carman_jason_58_main {
	//This is the main method, every program has one
	//and it runs the entire program
	public static void main(String[] args) {
		//Declare variables for menu choice and entered distance
		int menuChoice, convertDistance;
		//Creates a keyboard object for input
		Scanner keyboard = new Scanner(System.in);		
		//Loop so the program can keep running until the end user
		//enters the number 4.  Condition is below as part of while
		do {
			//Calls the menuOutput method which will show the menu	
			menuOutput();
			//Accepts input of the menu option and places into menuChoice variable
			menuChoice = keyboard.nextInt();
			//Loop to validate if the menu choice was not 1-4
			while (menuChoice < 1 || menuChoice > 4)
			{
				//Display showing the user error
				System.out.println("Invalid selection, please try again");
				//Calls the menuOutput method which will show the menu
				menuOutput();
				//Accepts input of the menu option and places into menuChoice variable
				menuChoice = keyboard.nextInt();
			}
			//Prompts user for input of distace
			System.out.println("Please enter distance");
			//Accepts input of the distance and places into convertDistance variable
			convertDistance = keyboard.nextInt();
			
			//Switch statement which takes the user entry for menu choice
			//and determines which conversion to run
			switch (menuChoice) {
				//Case one will pass the convertDistance variable to the
				//convertKilo class
				case 1: convertKilo(convertDistance);
					//If this is true, no need to check the other entries, so
					//the switch statement breaks
					break;
					//Case two will pass the convertDistance variable to the
					//convertInches class
				case 2: convertInches(convertDistance);
					//If this is true, no need to check the other entries, so
					//the switch statement breaks
					break;
					//Case three will pass the convertDistance variable to the
					//convertFeet class
				case 3: convertFeet(convertDistance);
					//If this is true, no need to check the other entries, so
					//the switch statement breaks
					break;
					//Case 4 ends the program, so it says goodbye
				case 4: System.out.println("Goodbye");
				}
		//Condition for the do while loop, keeps running until 4 is entered	
		} while (menuChoice != 4);
		
	}
	
	//Method for menu output, displays the prompts and information about
	//what each selection will do
	public static void menuOutput()  {
		System.out.println("Please select number");
		System.out.println("1.  Convert Kilometers");
		System.out.println("2.  Convert Inches");
		System.out.println("3.  Convert Feet");
		System.out.println("4.  End Program");		
	}
	
	//Method created for conversion to kilometers.  Takes the distance
	//entered as an argument, then performs the conversion calculation
	//Once calculation is complete, outputs the information to the screen
	public static void convertKilo(int methodDistance) {
		//Declaration of variable for answer, distance does not need to be 
		//declared since it is declared when the method is created.
		double kilometerDistance;
		//Calculation
		kilometerDistance = methodDistance * 0.001;
		//Output of answer
		System.out.println("Your distance in kilometers is " + kilometerDistance);		
	}
	
	//Method created for conversion to inches.  Takes the distance
	//entered as an argument, then performs the conversion calculation
	//Once calculation is complete, outputs the information to the screen
	public static void convertInches(int methodDistance) {
		//Declaration of variable for answer, distance does not need to be 
		//declared since it is declared when the method is created.
		double inchDistance;
		//Calculation
		inchDistance = methodDistance * 39.97;
		//Output of answer
		System.out.println("Your distance in inches is " + inchDistance);		
	}
	
	//Method created for conversion to feet.  Takes the distance
	//entered as an argument, then performs the conversion calculation
	//Once calculation is complete, outputs the information to the screen
	public static void convertFeet(int methodDistance) {
		//Declaration of variable for answer, distance does not need to be 
		//declared since it is declared when the method is created.
		double feetDistance;
		//Calculation
		feetDistance = methodDistance * 3.281;
		//Output of answer
		System.out.println("Your distance in feet is " + feetDistance);		
	}
	
}
