package carman_jason_chapter52;

import javax.swing.JOptionPane;

/*
 * Me
 * Summer
 * Chapter5-2
 * This program is going to do some math,
 *  with numbers we are passing to a method 
 */
public class Carman_jason_chapter52_main {
	//Main method, program starts here
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Declaration of variables, string for dialog
		//box input, then doubles for converting
		//the input and the answer
		String myInput;
		double myDoubleInput, myMainAnswer;
		//Dialog box that prompts the user for input
		//and places it into myINput variable
		myInput = JOptionPane.showInputDialog("Give me Number");
		//Converts the input string into a double and
		//places into myDoubleInput variable
		myDoubleInput = Double.parseDouble(myInput);
		//Call to the method below with hard coded
		//number as argument.  Performs the tasks in the
		//method, but does not output anything
		myMainAnswer = myCalculator(5);
		//Call to method below with variable a argument
		//Places the returned value from the method into
		//the myMainAnswer variable
		myMainAnswer = myCalculator(myDoubleInput);
		//Outputs the myMainAnswer variable
		System.out.println(myMainAnswer);
	}

	//This method will take a number and multiply
	//that number by .10
	public static double myCalculator(double myNumber) {
		//Declaration of variable for answer.  No declaration
		//is needed for number passed since it is declared
		//in the parenthesis of the method declaration 
		double myAnswer;
		//Multiplies the passed number by ,10 and places
		//into the myAnswer variable
		myAnswer = myNumber * .10;
		//Returns the myAnswr variable , this is what
		//gives the information back to the main method
		return myAnswer;
	}
	
	
	
	
	
}
